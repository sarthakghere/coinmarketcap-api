from django.contrib import admin
from .models import Coin, Job
# Register your models here.
admin.site.register(Coin)
admin.site.register(Job)